#include "paredes.h"
#include "game.h" // Para MAPA_LINHAS, MAPA_COLUNAS, TAM_BLOCO
#include "player.h" // Para Player struct em player_posicionar_no_ponto_p
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h> // ESSENCIAL: Necessario para al_draw_bitmap
#include <stdio.h> // Para fprintf e stderr


const char mapa[MAPA_LINHAS][MAPA_COLUNAS + 1] = {
    "################################################################################################################################################################",
    "#                                        #       #                   #       #                            #           #                                        #",
    "#                                        #       #                           #                            #           #                                        #",
    "#                                        #       #                           #                            #           #                                        #",
    "#                                        #                                   #                            #           #                                        #",
    "#                                        #                           #       #                            #           #                                        #",
    "#                                        #                           #       #                            #           #                                        #",
    "#                                                #                   #       #                            #           #                                        #",
    "#                                                #                   #       #                            #           #                                        #",
    "#                                                ########      #######       #                            #           #                                        #",
    "#                                        #       #                   #       #                            #           #                                        #",
    "#                                        #       #                   #       #                            #                                                    #",
    "#                                        #       #                   #       #                            #                                                    #",
    "#                                        #       #                           #                            #                                                    #",
    "#                                        #       #                           #################       ###########################################       #########",
    "#                                        #       #                                                                                                             #",
    "####################       ###############       #           #########                                                                                         #",
    "#                                                                    #                                                                                         #",
    "#                                                                    #                                                                                         #",
    "# P                                                                  #       ####################################       #                  #####################",
    "#                                                                    #                                          #       #                                      #",
    "#                                                                    #                                          #       #                                      #",
    "######       #####################################       #############                                          #       #                                      #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                 #                                  #       #                                  #       #                  #                   #",
    "#                                                                    #       #                                  #       #                  #                   #",
    "#                                                                    #       #                                  #       #                  #                   #",
    "#                                                                    #       ####################################       #                  #                   #",
    "#       ###########      ##########                                                                                                        #######       #######",
    "#                                 #                                                                                                        #                   #",
    "#                                 #                                                                                                                            #",
    "#                                 #                                  #       #                                          #                                      #",
    "#                                 #                                  #       #                                          #                                      #",
    "#                                 #                                  #       #                                          #                  #                   #",
    "######################################################################       ###############################################################                   #",
    "#                                                                    #                                                  ####################                   #",
    "#                                                                    #                                                  ####################                   #",
    "#                                                                    #                                                  ####################                   #",
    "#                                                                    #       #                                          ########################################",
    "#                                                                    #       #                                          ########################################",
    "#                                                                    #       #                                          ########################################",
    "#                                                                            #                                          ########################################",
    "#                                                                            #                                          ########################################",
    "#                                                                            #                                          ########################################",
    "#                                                                    #       #                                          ########################################",
    "#                                                                    #       #                                          ########################################",
    "#                                                                    #       #                                          ########################################",
    "#                                                                    #                                                  ########################################",
    "#                                                                    #                                                  ########################################",
    "#                                                                    #                                                  ########################################",
    "#            ############################################            ###########################################################################################",
    "#            ############################################            ###########################################################################################",
    "#            ############################################            ###########################################################################################",
    "#            ############################################            ###########################################################################################",
    "################################################################################################################################################################"
};

extern ALLEGRO_BITMAP *chao_sprite;
extern ALLEGRO_BITMAP *parede_sprite;

void paredes_init() {
    // Sprites sao carregadas em game_init
}

void paredes_draw(float camera_x, float camera_y) {
    for (int i = 0; i < MAPA_LINHAS; i++) {
        for (int j = 0; j < MAPA_COLUNAS; j++) {
            float x = j * TAM_BLOCO - camera_x;
            float y = i * TAM_BLOCO - camera_y;

            if (mapa[i][j] == '#') {
                if (parede_sprite) {
                    al_draw_bitmap(parede_sprite, x, y, 0);
                } else {
                    al_draw_filled_rectangle(x, y, x + TAM_BLOCO, y + TAM_BLOCO, al_map_rgb(100, 100, 100));
                }
            } else { // Se nao eh parede, eh chao (inclui 'P' e espacos vazios)
                if (chao_sprite) {
                    al_draw_bitmap(chao_sprite, x, y, 0);
                } else {
                    al_draw_filled_rectangle(x, y, x + TAM_BLOCO, y + TAM_BLOCO, al_map_rgb(50, 50, 50));
                }
            }
        }
    }
}

bool paredes_colisao(float x, float y, float largura, float altura) {
    int inicio_x = (int)(x / TAM_BLOCO);
    int inicio_y = (int)(y / TAM_BLOCO);
    int fim_x = (int)((x + largura - 1) / TAM_BLOCO);
    int fim_y = (int)((y + altura - 1) / TAM_BLOCO);

    if (inicio_x < 0) inicio_x = 0;
    if (inicio_y < 0) inicio_y = 0;
    if (fim_x >= MAPA_COLUNAS) fim_x = MAPA_COLUNAS - 1;
    if (fim_y >= MAPA_LINHAS) fim_y = MAPA_LINHAS - 1;

    for (int i = inicio_y; i <= fim_y; i++) {
        for (int j = inicio_x; j <= fim_x; j++) {
            if (mapa[i][j] == '#') {
                return true;
            }
        }
    }
    return false;
}

void paredes_destroy() {
    // Sprites sao destruidas em game_destroy
}

void player_posicionar_no_ponto_p(Player *player) {
    for (int linha = 0; linha < MAPA_LINHAS; linha++) {
        for (int col = 0; col < MAPA_COLUNAS; col++) {
            if (mapa[linha][col] == 'P') {
                player->x = col * TAM_BLOCO;
                player->y = linha * TAM_BLOCO;
                return;
            }
        }
    }
    fprintf(stderr, "Aviso: Ponto 'P' nao encontrado no mapa. Posicionando jogador em (0,0).\n");
    player->x = 0;
    player->y = 0;
}
