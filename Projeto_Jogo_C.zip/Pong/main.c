#include <stdio.h>
#include <allegro5/allegro.h> // Necessario para al_is_system_installed
#include "game.h" // Inclui game.h para acessar funcoes do jogo

int main(void) {
    // 1. Inicializa todos os subsistemas do Allegro e carrega recursos (fontes, imagens, audio)
    game_init();

    // Opcional: Verifica se o Allegro foi inicializado corretamente (boa pratica)
    if (!al_is_system_installed()) {
        fprintf(stderr, "Erro: Allegro nao foi inicializado corretamente ou falhou em game_init().\n");
        return 1; // Retorna codigo de erro
    }

    // 2. Executa o loop principal do jogo (onde toda a logica de atualizacao e desenho acontece)
    game_loop();

    // 3. Libera todos os recursos alocados pelo Allegro e modulos do jogo
    game_destroy();

    return 0; // Retorna sucesso
}
