#ifndef ITEM_H
#define ITEM_H

#include <stdbool.h>
#include "player.h"
#include <allegro5/allegro.h> // Necessario para ALLEGRO_BITMAP

#define MAX_ITENS 5
#define ITEM_SIZE 20.0f // Certifique-se de que este tamanho corresponde ao da sua sprite
#define DISTANCIA_MIN_GERACAO 200.0f

typedef struct {
    float x, y;
    bool ativo;
} Item;

// Declaracao externa da sprite do item (definida em game.c)
extern ALLEGRO_BITMAP *item_sprite;

void itens_init();
void itens_update(Player *player);
void itens_draw(float camera_x, float camera_y);
int itens_get_coletados();
void itens_reset();

void itens_gerar_proximo(float ultima_x, float ultima_y);

#endif // ITEM_H
