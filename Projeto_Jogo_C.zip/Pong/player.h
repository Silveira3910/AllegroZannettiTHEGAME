#ifndef PLAYER_H
#define PLAYER_H

#include <stdbool.h>
#include <allegro5/allegro.h> // Necessario para ALLEGRO_BITMAP

#define PLAYER_SIZE 32.0f // Certifique-se de que este valor corresponde ao tamanho da sua sprite
#define PLAYER_SPEED 3.0f

typedef struct {
    float x, y;
    float largura, altura;
    float speed;
} Player;

// Declaracao externa da sprite do jogador (definida em game.c)
extern ALLEGRO_BITMAP *player_sprite;

void player_init(Player *p);
void player_update(Player *p, const bool keys[]);
void player_draw(const Player *p, float camera_x, float camera_y);
void player_destroy();

#endif // PLAYER_H
