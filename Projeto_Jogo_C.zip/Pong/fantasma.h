#ifndef FANTASMA_H
#define FANTASMA_H

#include <stdbool.h>
#include "player.h"
#include <allegro5/allegro.h> // Necessario para ALLEGRO_BITMAP

#define MAX_FANTASMAS 12
#define FANTASMA_SIZE 32.0f // Certifique-se de que este valor corresponde ao tamanho da sua sprite
#define TEMPO_EXPOSICAO_LUZ 3.0f
#define RAIO_LUZ 150.0f
#define ANGULO_LUZ (ALLEGRO_PI / 4.0f)

typedef struct {
    float x, y;
    float dx, dy;
    float tempo_direcao;
    float tempo_exposto;
    bool ativo;
} Fantasma;

// Declaracao externa da sprite do fantasma (definida em game.c)
extern ALLEGRO_BITMAP *fantasma_sprite;

void fantasmas_init();
void fantasmas_update(const Player *player);
void fantasmas_draw(float camera_x, float camera_y);
bool fantasmas_check_collision(const Player *player);
void fantasmas_destroy();

#endif // FANTASMA_H
